import pandas as pd
import numpy as np 
from sklearn.model_selection import train_test_split

df = pd.read_csv('breast-cancer-wisconsin.data')
df.replace('?', -99999, inplace=True) #-99999 -> outlier
df.drop(['id'], 1, inplace=True)

#X -> features, y -> label
X = np.array(df.drop(['class'], 1))
y = np.array(df['class'])

X_train, X_test, y_train, y_test = sklearn.model_selection.train_test_split(X, y, test_size = 0.2)

#classifier
clf = neigbors.KNeighborsClassifier()
clf.fit(X_train, y_train)

acc = clf.score(X_test, y_test)
print(acc)

example_measures = np.array([4, 2, 1, 1, 1, 2, 3, 2, 1]) # 1 sample
example_measures = example_measures.reshape(len(example_measures), -1) #1 is for 1 sample. len() -> more dynamic

prediction = clf.predict(example_measures)
print(prediction)